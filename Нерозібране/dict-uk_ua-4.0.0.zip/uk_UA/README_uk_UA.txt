This is Ukrainian spelling dictionary, thesaurus, and hyphenation rules for LibreOffice.org
that use hunspell as spelling engine and it is based on 
dictionary of dict_uk project https://github.com/brown-uk/dict_uk

oxt package authors:
  Andriy Rysin <arysin@gmail.com>, 2007 — 2017

This dictionary is licensed under MPL (Mozilla Public License) 1.1 license.
