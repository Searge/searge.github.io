This is Ukrainian thesaurus for OpenOffice.org version 1.6.0.

This thesaurus is based on:
П. М. Деркач, Короткий словник синонімів української мови, Радянська школа, Київ, 1960
С. Караванський, Пошук українського слова

Copyright (C) 2009, 2016
    Andriy Rysin

This thesaurus is licensed under GPL, LGPL and MPL (Mozilla Public License) licenses.
